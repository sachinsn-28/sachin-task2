# SoftNexis — Servlet-Based Contact Manager

A Java Servlet/JSP contact-management web application for Task 2. It supports listing, adding, editing, deleting, server-side validation, search-as-you-type, success/error feedback, and session-based in-memory storage.

## Requirements
- JDK 8 or later
- Maven 3.6+
- Apache Tomcat 9 (uses `javax.servlet`; do not use Tomcat 10 without migrating to `jakarta.servlet`)

## Run
1. Open a terminal in this folder.
2. Build: `mvn clean package`
3. Copy `target/contact-manager.war` to Tomcat's `webapps` folder.
4. Start Tomcat and open `http://localhost:8080/contact-manager/contacts`.

Data is stored in the HTTP session, as requested in the brief. It is not database-persistent and is cleared when the session expires.

## Routes
- `GET /contacts` — list/search contacts
- `GET /contacts/add` — show add form
- `POST /contacts` — validate and create contact
- `GET /contacts/edit?id=...` — show edit form
- `POST /contacts/update` — validate and update contact
- `POST /contacts/delete` — delete contact

## Notes
- Name is required and must contain 2–50 characters.
- Email is required and must have a valid basic email format.
- Phone is optional; when supplied, it must contain exactly 10 digits.
- JSP output uses JSTL `<c:out>` to escape user-provided text and reduce XSS risk.
- For production, add authentication/authorization, CSRF tokens, a database repository, and logging.
