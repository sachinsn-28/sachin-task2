(function () {
  "use strict";
  var search = document.getElementById("search");
  var table = document.getElementById("contactTable");
  var noResults = document.getElementById("noResults");
  if (search && table) {
    search.addEventListener("input", function () {
      var query = search.value.toLowerCase().trim();
      var rows = table.querySelectorAll("tbody tr");
      var visible = 0;
      rows.forEach(function (row) {
        var match = row.textContent.toLowerCase().indexOf(query) !== -1;
        row.hidden = !match;
        if (match) visible++;
      });
      if (noResults) noResults.hidden = visible !== 0;
    });
  }

  var form = document.getElementById("contactForm");
  if (!form) return;
  var name = document.getElementById("name");
  var email = document.getElementById("email");
  var phone = document.getElementById("phone");
  var submit = document.getElementById("submitButton");
  var emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
  function setError(input, message) {
    var target = document.getElementById(input.id + "Error");
    if (target) target.textContent = message || "";
    input.classList.toggle("invalid", !!message);
    input.setAttribute("aria-invalid", message ? "true" : "false");
  }
  function validateName() {
    var value = name.value.trim();
    var error = value.length < 2 || value.length > 50 ? "Please enter valid name (2–50 characters)." : "";
    setError(name, error); return !error;
  }
  function validateEmail() {
    var value = email.value.trim();
    var error = !emailPattern.test(value) ? "Invalid email address." : "";
    setError(email, error); return !error;
  }
  function validatePhone() {
    var value = phone.value.trim();
    var error = value && !/^\d{10}$/.test(value) ? "Use 10-digit format." : "";
    setError(phone, error); return !error;
  }
  name.addEventListener("blur", validateName);
  email.addEventListener("blur", validateEmail);
  phone.addEventListener("blur", validatePhone);
  form.addEventListener("submit", function (event) {
    var validName = validateName(), validEmail = validateEmail(), validPhone = validatePhone();
    if (!validName || !validEmail || !validPhone) {
      event.preventDefault();
      if (!validName) name.focus(); else if (!validEmail) email.focus(); else phone.focus();
      return;
    }
    if (submit) { submit.disabled = true; submit.textContent = "Saving…"; }
  });
})();