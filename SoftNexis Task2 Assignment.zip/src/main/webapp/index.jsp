<%
response.sendRedirect(request.getContextPath() + "/contacts");
%>