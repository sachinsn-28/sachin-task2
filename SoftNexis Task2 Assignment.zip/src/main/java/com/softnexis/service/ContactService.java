package com.softnexis.service;

import com.softnexis.model.Contact;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

public final class ContactService {
    private static final String KEY = "contacts";
    private static final String NEXT_ID = "nextContactId";
    private ContactService() {}

    @SuppressWarnings("unchecked")
    public static List<Contact> all(HttpSession session) {
        List<Contact> contacts = (List<Contact>) session.getAttribute(KEY);
        if (contacts == null) {
            contacts = new ArrayList<Contact>();
            session.setAttribute(KEY, contacts);
            session.setAttribute(NEXT_ID, 1);
        }
        return contacts;
    }

    public static Contact find(HttpSession session, int id) {
        for (Contact c : all(session)) if (c.getId() == id) return c;
        return null;
    }

    public static Contact add(HttpSession session, String name, String email, String phone) {
        Integer next = (Integer) session.getAttribute(NEXT_ID);
        if (next == null) next = 1;
        Contact c = new Contact(next, name, email, phone);
        all(session).add(c);
        session.setAttribute(NEXT_ID, next + 1);
        return c;
    }

    public static boolean update(HttpSession session, int id, String name, String email, String phone) {
        Contact c = find(session, id);
        if (c == null) return false;
        c.setName(name); c.setEmail(email); c.setPhone(phone);
        return true;
    }

    public static boolean delete(HttpSession session, int id) {
        Contact c = find(session, id);
        return c != null && all(session).remove(c);
    }
}