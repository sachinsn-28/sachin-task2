package com.softnexis.web;

import com.softnexis.service.ContactService;
import com.softnexis.util.ContactValidator;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Map;

@WebServlet("/contacts")
public class AddContactServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String name = clean(request.getParameter("name"));
        String email = clean(request.getParameter("email"));
        String phone = clean(request.getParameter("phone"));
        Map<String, String> errors = ContactValidator.validate(name, email, phone);
        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.setAttribute("nameValue", name);
            request.setAttribute("emailValue", email);
            request.setAttribute("phoneValue", phone);
            request.setAttribute("pageTitle", "Add Contact");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp").forward(request, response);
            return;
        }
        ContactService.add(request.getSession(), name.trim(), email.trim(), phone.trim());
        request.getSession().setAttribute("success", "Contact added successfully.");
        response.sendRedirect(request.getContextPath() + "/contacts");
    }
    private String clean(String value) { return value == null ? "" : value.trim(); }
}