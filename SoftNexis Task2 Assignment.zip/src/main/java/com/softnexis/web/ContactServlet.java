package com.softnexis.web;

import com.softnexis.model.Contact;
import com.softnexis.service.ContactService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = {"/contacts", "/contacts/add", "/contacts/edit"})
public class ContactServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();
        if ("/contacts/add".equals(path)) {
            request.setAttribute("pageTitle", "Add Contact");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp").forward(request, response);
            return;
        }
        if ("/contacts/edit".equals(path)) {
            int id = parseId(request.getParameter("id"));
            Contact contact = ContactService.find(request.getSession(), id);
            if (contact == null) {
                request.getSession().setAttribute("error", "Contact not found.");
                response.sendRedirect(request.getContextPath() + "/contacts");
                return;
            }
            request.setAttribute("contact", contact);
            request.setAttribute("pageTitle", "Edit Contact");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp").forward(request, response);
            return;
        }
        List<Contact> all = ContactService.all(request.getSession());
        request.setAttribute("contacts", new ArrayList<Contact>(all));
        request.getRequestDispatcher("/WEB-INF/views/contact-list.jsp").forward(request, response);
    }
    private int parseId(String raw) {
        try { return Integer.parseInt(raw); } catch (Exception e) { return -1; }
    }
}