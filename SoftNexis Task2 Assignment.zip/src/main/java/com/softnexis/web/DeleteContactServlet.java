package com.softnexis.web;

import com.softnexis.service.ContactService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/contacts/delete")
public class DeleteContactServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id;
        try { id = Integer.parseInt(request.getParameter("id")); }
        catch (Exception e) { id = -1; }
        if (ContactService.delete(request.getSession(), id))
            request.getSession().setAttribute("success", "Contact deleted successfully.");
        else
            request.getSession().setAttribute("error", "Contact could not be found.");
        response.sendRedirect(request.getContextPath() + "/contacts");
    }
}