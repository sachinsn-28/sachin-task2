package com.softnexis.web;

import com.softnexis.model.Contact;
import com.softnexis.service.ContactService;
import com.softnexis.util.ContactValidator;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Map;

@WebServlet("/contacts/update")
public class UpdateContactServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        int id;
        try { id = Integer.parseInt(request.getParameter("id")); }
        catch (Exception e) { id = -1; }
        String name = clean(request.getParameter("name"));
        String email = clean(request.getParameter("email"));
        String phone = clean(request.getParameter("phone"));
        Contact existing = ContactService.find(request.getSession(), id);
        if (existing == null) {
            request.getSession().setAttribute("error", "Contact not found.");
            response.sendRedirect(request.getContextPath() + "/contacts");
            return;
        }
        Map<String, String> errors = ContactValidator.validate(name, email, phone);
        if (!errors.isEmpty()) {
            Contact submitted = new Contact(id, name, email, phone);
            request.setAttribute("contact", submitted);
            request.setAttribute("errors", errors);
            request.setAttribute("pageTitle", "Edit Contact");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp").forward(request, response);
            return;
        }
        ContactService.update(request.getSession(), id, name, email, phone);
        request.getSession().setAttribute("success", "Contact updated successfully.");
        response.sendRedirect(request.getContextPath() + "/contacts");
    }
    private String clean(String value) { return value == null ? "" : value.trim(); }
}